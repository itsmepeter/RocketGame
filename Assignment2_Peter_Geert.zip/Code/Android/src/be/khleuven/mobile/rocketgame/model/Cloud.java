package be.khleuven.mobile.rocketgame.model;

import android.graphics.Bitmap;

public class Cloud extends SpaceObject {

	public Cloud(int x, int y, Bitmap image, int width) {
		super(x, y, image, width);
		
	}

}
